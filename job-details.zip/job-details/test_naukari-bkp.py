import asyncio
import json
from datetime import datetime
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as p:
        # Launch the browser
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        job_title = 'Intern'
        job_location = 'Worldwide'

        # with open("linkedin_cookie.json", "r") as f:
        #     cookies = json.loads(f.read())

        await page.goto(f"https://www.naukri.com/intern-jobs?k={job_title}", wait_until="domcontentloaded")
        await page.wait_for_timeout(4000)

        main_div = page.locator("#listContainer")
        second_div = main_div.locator("> div").nth(1)
        inner_div = second_div.locator("> div")
        sub_divs = inner_div.locator("> div")
        sub_div_count = await sub_divs.count()
        print("a_tag.get_attribute('href')",sub_div_count)
        # Iterate over each <sub div> element
        for i in range(sub_div_count):
            sub_div = sub_divs.nth(i)  # Get the i-th <sub div>
            job_div = sub_div.locator('a.title')
            link = await job_div.get_attribute('href')
            job_title = await job_div.inner_text()
            comp_name_div = sub_div.locator('a.comp-name')
            company = await comp_name_div.inner_text()
            company_url = await comp_name_div.get_attribute('href')

            job_detail_div = sub_div.locator('div.job-details')
            span_elements = job_detail_div.locator("span")
            span_count = await span_elements.count()
            job_meta = []
            for j in range(span_count):
                span = span_elements.nth(j)  # Get the i-th <span>
                span_text = await span.inner_text()  # Get the inner text of the span element
                job_meta.append(span_text)
            seen = set()
            job_meta_unique = [item for item in job_meta if not (item in seen or seen.add(item))]

            closing_div = sub_div.locator('div.closing-soon p')
            closing_detail = await closing_div.inner_text()

            joining_div = sub_div.locator('span.job-post-day')
            joining_detail = await joining_div.inner_text()

            print('link', link)
            print('job title', job_title)
            print("company",company)
            print("company_url",company_url)
            print("job_meta",job_meta_unique)
            print("closing_detail",closing_detail)
            print("joining_detail",joining_detail)

            breakpoint()




        await browser.close()


asyncio.run(main())
