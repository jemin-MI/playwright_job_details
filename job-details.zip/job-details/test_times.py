import asyncio
import json
from pydoc import describe
from subprocess import check_output

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
from sqlalchemy.util import await_only


def html_to_text(html_content):
    """
    Converts HTML content to plain text.

    Args:
        html_content (str): HTML string to convert.

    Returns:
        str: Plain text extracted from the HTML.
    """
    soup = BeautifulSoup(html_content, 'html.parser')

    # Define a list to hold the formatted text parts
    formatted_text = []

    # Iterate through all elements in the parsed HTML
    for element in soup.descendants:
        if element.name in ["h1", "h2", "h3", "h4", "h5", "h6"]:  # Heading tags
            formatted_text.append(f"[heading] {element.get_text(strip=True)}")
        elif element.name == "strong":  # Bold tags
            formatted_text.append(f"[bold] {element.get_text(strip=True)}")
        elif element.name == "br":  # Line breaks
            formatted_text.append("\n")
        elif element.name is None and element.strip():  # Plain text
            formatted_text.append(element.strip())

    # Combine all parts with spaces to form the final string
    return " ".join(formatted_text)


async def main():
    async with async_playwright() as p:
        # Launch the browser
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context()
        page = await context.new_page()

        job_title_input = 'Intern'
        job_location_input = 'Ahmedabad'
        job_experiance_input ='1 Year'
        page_count = 2

        # with open("linkedin_cookie.json", "r") as f:
        #     cookies = json.loads(f.read())

        await page.goto(f"https://www.timesjobs.com/", wait_until="domcontentloaded")
        await page.wait_for_timeout(4000)

        await page.fill('#txtKeywords', job_title_input)
        # await page.locator('span._selectedValueExp').fill(job_experiance_input)
        await page.fill('#txtLocation', job_location_input)

        await page.locator('#quickSearchBean .common-btn').press('Enter')
        await page.wait_for_timeout(5000)

        breakpoint()


        form_div = page.locator('#searchForm')
        submit_button = form_div.locator('.search_submit_btn').nth(0)
        await submit_button.click()
        await page.wait_for_timeout(5000)




        pagewise = []
        for current_page in range(page_count):

            data_list = []
            main_div = page.locator('.srpResultCard > div')
            count = await main_div.count()

            for i in range(count):
                card = main_div.nth(i)
                await card.click()
                await page.wait_for_timeout(1500)

                job = page.locator('.jdTitle')
                job_title = await job.inner_text()
                print("job_title-----------", job_title)

                company = page.locator('.jdCompanyName')
                company_name = await company.inner_text()
                print("company_name--------", company_name)

                job_lable = page.locator('.jobLabelContainer')

                label_text = ''
                if await job_lable.count() > 0:
                    label_text = await job_lable.locator('.jobLabels .labelText').inner_text()
                    print('job_lable_text----------', label_text)

                bullets_div = page.locator('.bulletText')
                ul_element = bullets_div.locator('ul.text-list')
                li_elements = ul_element.locator('li')

                li = li_elements.nth(0).locator('span')  # Get the i-th 'li' element
                posted_on = await li.inner_text()  # Get the text of the 'span'
                print(f"Posted: --------------{posted_on}")

                li = li_elements.nth(1).locator('span')  # Get the i-th 'li' element
                applicant = await li.inner_text()  # Get the text of the 'span'
                print(f"Applicant:----------- {applicant}")

                highlights = page.locator('.jdHighlights')

                experiance =(await highlights.locator('.highlightsRow').nth(0).inner_text()).replace('Exp: ', '')
                print("experiance---------", experiance)

                location = await highlights.locator('.highlightsRow').nth(1).inner_text()
                print("location---------", location)

                description = page.locator('.jobDescInfoNew')
                description_html = await description.inner_html()
                description_text = html_to_text(description_html)
                print("description_text---------", description_text)

                info_container = page.locator('.infoContainer p')
                industry =await info_container.nth(0).locator('span').nth(1).inner_text()
                industry_function =await info_container.nth(1).locator('span').nth(1).inner_text()
                job_type =await info_container.nth(2).locator('span').nth(1).inner_text()

                print("industry--------",industry )
                print("industry_function --------", industry_function)
                print("job_type--------", job_type)

                skills_container = page.locator('.pillsContainer')
                skills_list = skills_container.locator('.pillItem')

                skill_list = []
                for s in  range(await skills_list.count()):
                    skill_text = await skills_list.nth(s).inner_text()
                    skill_list.append(skill_text)

                print("skill set--------", skill_list)


                report_job = page.locator('.reportJobContainer')

                posted_on = await report_job.locator('p').nth(0).inner_text()
                job_id = await report_job.locator('p').nth(1).inner_text()

                print("posted_on------", posted_on)
                print("job_id------", job_id)


                data_dict = {'job_title': job_title, 'company_name':company_name, 'label_text':label_text or None, 'posted_on':posted_on, 'applicant':applicant, 'industry':industry,'industry_function':industry_function,'job_type':job_type,'skill_list':skill_list,'job_id':job_id,'description_text':description_text }
                data_list.append(data_dict)
                with open('found_data.json' , 'w') as file:
                    file.write(json.dumps(data_list))

            current_page += 1
            pagewise.append({"page" + str(current_page): data_list})
            pagewise.append(data_list)

            with open('pagewise_found.json', 'w') as file:
                file.write(json.dumps(pagewise))

            pagination = page.locator('.pagination .arrow-right')

            if await pagination.count() > 0 and page_count > 1 :
                await pagination.click()

                print("clicked page")
            if page_count > 1 and await pagination.locator(".arrow-right").count() == 0:
                break

        await browser.close()

asyncio.run(main())
